# illegally parked scooter > 2024-06-11 10:46am
https://universe.roboflow.com/test-pdfzl/illegally-parked-scooter

Provided by a Roboflow user
License: Public Domain

